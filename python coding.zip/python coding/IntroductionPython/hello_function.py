#!/usr/bin/env python3

def hello_world ():
    print ("Hello World !")

a = hello_world ()
print (a)
