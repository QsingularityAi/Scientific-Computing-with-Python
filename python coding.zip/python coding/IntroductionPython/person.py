#!/usr/bin/env python3

def printContact (name ,age , location ):
    print ("Person : ", name )
    print ("Age : ", age , "years ")
    print ("Address : ", location )

printContact ( name =" Peter Pan", location =" Neverland ", age =10)
