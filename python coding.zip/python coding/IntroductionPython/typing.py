#!/usr/bin/env python3
number = 3
print (number , type ( number ))
print ( number + 42)
number = "3"
print (number , type ( number ))
print ( number + 42)
