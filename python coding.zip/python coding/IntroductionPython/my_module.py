def add(a, b):
    """ Add a and b."""
    return a + b

print (add (2, 3))
