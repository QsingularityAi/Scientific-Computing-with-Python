#!/usr/bin/env python3
name=input("What's your name? ")
print("Hello ",name)
